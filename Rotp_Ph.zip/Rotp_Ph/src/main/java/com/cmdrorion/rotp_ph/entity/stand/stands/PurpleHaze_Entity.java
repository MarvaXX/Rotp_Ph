package com.cmdrorion.rotp_ph.entity.stand.stands;

import com.github.standobyte.jojo.entity.stand.StandEntity;
import com.github.standobyte.jojo.entity.stand.StandEntityType;

import net.minecraft.world.World;

public class PurpleHaze_Entity extends StandEntity {
    
    public PurpleHaze_Entity(StandEntityType<PurpleHaze_Entity> type, World world) {
        super(type, world);
    }
}